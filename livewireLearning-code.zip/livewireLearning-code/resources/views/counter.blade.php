<div>
    <h3 class="text-gray-700 text-3xl font-medium">Dashboard</h3>
    @livewire('counter')  {{-- Render Livewire component here --}}
</div>
