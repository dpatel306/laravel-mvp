<div class="container mx-auto px-6 py-8">
<div class="flex flex-col">
    <h2>Count Number : {{$count}}</h2>
    <div class="flex-start">
        <button type="button" wire:click="increment">Increment</button>
        <button type="button" wire:click="decrement">Decrement</button>
    </div>
</div>
</div>
