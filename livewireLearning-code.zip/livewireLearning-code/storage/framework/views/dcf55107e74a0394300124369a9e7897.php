<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e($title ?? 'Page Title'); ?></title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body>
    <div x-data="{ sidebarOpen: false,darkMode: false }" class="flex h-screen bg-gray-200 font-roboto" :class="{'dark text-bodydark bg-boxdark-2': darkMode === true}">
        <?php if(auth()->guard('admin')->check()): ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('component.sidebar');

$__html = app('livewire')->mount($__name, $__params, 'lw-3587659519-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php endif; ?>
        <div class="flex-1 flex flex-col overflow-hidden">
            <?php if(auth()->guard('admin')->check()): ?>
                
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('component.header');

$__html = app('livewire')->mount($__name, $__params, 'lw-3587659519-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php endif; ?>
            <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">                
                    <?php echo e($slot); ?>                
            </main>
            <?php if(auth()->guard('admin')->check()): ?>
                
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('component.footer');

$__html = app('livewire')->mount($__name, $__params, 'lw-3587659519-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php endif; ?>
        </div>
    </div>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html><?php /**PATH /home/atyantik/workspace/learning/livewireLearning/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>