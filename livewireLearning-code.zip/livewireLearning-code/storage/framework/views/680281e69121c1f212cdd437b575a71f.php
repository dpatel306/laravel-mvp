<div class="container mx-auto px-6 py-8">
<div>
    Hey, Pooja
</div>
</div>
<?php /**PATH /home/atyantik/workspace/learning/livewireLearning/resources/views/livewire/dashboard.blade.php ENDPATH**/ ?>