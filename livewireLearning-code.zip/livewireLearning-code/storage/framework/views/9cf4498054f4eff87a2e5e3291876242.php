<footer class="flex items-center justify-between px-6 py-4 bg-white border-b-4 border-indigo-600 dark:bg-boxdark dark:drop-shadow-none">
    <h2>Footer</h2>
</footer><?php /**PATH /home/atyantik/workspace/learning/livewireLearning/resources/views/livewire/component/footer.blade.php ENDPATH**/ ?>